# -*- coding: utf-8 -*-
#!/usr/bin/env python3

"""
Created on Fri May 31 08:44:49 2024

@author: ron
"""

import os
import numpy as np
from myptv.imaging_mod import camera_wrapper


# load Markers:
cases_folder = '/home/ron/Desktop/Research/PTV cases/rbc300/MyPTV_analysis/line_of_sight/proPTV_OpenPTV_MyPTV_comparison/cases/case_allmarkers'
marker_fnames = sorted(os.listdir(cases_folder))
markers = np.loadtxt(os.path.join(cases_folder, marker_fnames[0]))[:,2:]


# load camera:
camNums = [0,1,2,3]
for cn in camNums:
    cam_fname = 'cam%s'%cn
    cam_folder = '/home/ron/Desktop/Research/PTV cases/rbc300/MyPTV_analysis/cam_extendedZolof'
    cam = camera_wrapper(cam_fname, cam_folder)
    cam.load()
    
    
    # calculate and save projections:
    projections = np.array([cam.projection(m) for m in markers])
    np.savetxt('MyPTV_projection_results/MyPTV_extendedZolof_xy_allmarkers_c%s.txt'%(cn), projections)









